// All values below are illustrative demo data, not live sensor readings.
const currentReading = {
  tankName: "Village Tank 01",
  location: "Sample Village, Tamil Nadu",
  ph: 7.2,
  turbidityVoltage: 2.1,
  status: "Review reading",
  updated: "Demo snapshot · 10:30 AM"
};

const history = [
  { date: "2026-10-26", ph: 7.2, turbidityVoltage: 2.1, note: "Demo reading" },
  { date: "2026-10-25", ph: 7.1, turbidityVoltage: 2.0, note: "Demo reading" },
  { date: "2026-10-24", ph: 6.8, turbidityVoltage: 2.4, note: "Recheck suggested" },
  { date: "2026-10-23", ph: 7.0, turbidityVoltage: 2.2, note: "Demo reading" }
];

document.getElementById("tankName").textContent = currentReading.tankName;
document.getElementById("location").textContent = currentReading.location;
document.getElementById("phValue").textContent = currentReading.ph.toFixed(1);
document.getElementById("turbidityValue").textContent = `${currentReading.turbidityVoltage.toFixed(1)} V`;
document.getElementById("statusValue").textContent = currentReading.status;
document.getElementById("lastUpdated").textContent = currentReading.updated;

const rows = document.getElementById("historyRows");
history.forEach((reading) => {
  const tr = document.createElement("tr");
  [reading.date, reading.ph.toFixed(1), `${reading.turbidityVoltage.toFixed(1)} V`, reading.note]
    .forEach((value) => {
      const td = document.createElement("td");
      td.textContent = value;
      tr.appendChild(td);
    });
  rows.appendChild(tr);
});
