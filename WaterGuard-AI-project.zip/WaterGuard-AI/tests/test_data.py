"""Basic structural checks for the included sample dataset."""
from pathlib import Path
import csv
import unittest

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "sample_water_quality.csv"

class SampleDataTests(unittest.TestCase):
    def test_dataset_has_expected_columns_and_rows(self):
        with DATA_FILE.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        self.assertEqual(
            reader.fieldnames,
            ["record_id", "date", "ph_estimate", "turbidity_voltage", "demo_label"],
        )
        self.assertGreaterEqual(len(rows), 20)

    def test_demo_labels_are_known(self):
        with DATA_FILE.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        allowed = {"review", "follow_up"}
        self.assertTrue(all(row["demo_label"] in allowed for row in rows))

if __name__ == "__main__":
    unittest.main()
