# WaterGuard AI – Architecture

## Prototype data flow

```text
pH sensor ─────┐
               ├─> Arduino analog readings ─> Serial output
Turbidity sensor┘                              │
                                               ├─> Dashboard (demo data today)
                                               └─> Future API/backend integration
                                                            │
                                                            v
                                              Data validation and storage
                                                            │
                                                            v
                                              Reviewed rules / ML analysis
                                                            │
                                                            v
                                              Dashboard + responsible-team alert
```

## Current implementation

- **Hardware:** Arduino sketch reads two analog sensor outputs and prints CSV-like records over Serial.
- **Frontend:** static HTML/CSS/JavaScript dashboard with clearly marked sample values.
- **ML demo:** scikit-learn Random Forest trained on a small synthetic dataset.
- **Data:** synthetic sample rows for testing the workflow.
- **Not implemented yet:** direct serial-to-browser streaming, cloud database, QR generation, SMS/WhatsApp delivery, and a validated water-quality prediction model.

## Production-oriented improvements

1. Define data fields and units for the exact sensor modules.
2. Calibrate sensors and validate measurements against reference methods.
3. Add a backend API with authentication and input validation.
4. Store readings with timestamps, tank IDs, sensor calibration metadata, and audit history.
5. Use secure QR-linked pages and avoid publishing sensitive personal information.
6. Create alert escalation with a human review process.
7. Train and independently evaluate models using representative, expert-reviewed measurements.
8. Monitor sensor drift, missing values, false alerts, and model performance over time.

## Responsible interpretation

A pH or turbidity reading alone cannot establish that water is safe to drink. Water safety can depend on microbial and chemical contaminants that this prototype does not measure. A qualified testing process and applicable local standards are necessary.
