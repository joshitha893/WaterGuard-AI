/*
  WaterGuard AI - educational sensor-reading prototype
  Example connections:
    pH module analog output -> A0
    Turbidity module analog output -> A1

  IMPORTANT:
  - The pH and turbidity conversion formulas below are illustrative placeholders.
  - Calibrate for your exact modules before using readings.
  - This prototype cannot certify drinking-water safety.
*/

const int PH_PIN = A0;
const int TURBIDITY_PIN = A1;

const float ADC_REFERENCE_V = 5.0;  // Change if your board/reference differs
const int ADC_MAX = 1023;

// Demonstration threshold only; confirm appropriate thresholds with experts.
const float DEMO_PH_MIN = 6.5;
const float DEMO_PH_MAX = 8.5;
const float DEMO_TURBIDITY_VOLTAGE_LIMIT = 2.5; // Placeholder, module-dependent

float readVoltage(int pin) {
  int raw = analogRead(pin);
  return raw * (ADC_REFERENCE_V / ADC_MAX);
}

void setup() {
  Serial.begin(9600);
  Serial.println("WaterGuard AI sensor prototype starting...");
  Serial.println("pH_voltage_V,turbidity_voltage_V,demo_status");
}

void loop() {
  float phVoltage = readVoltage(PH_PIN);
  float turbidityVoltage = readVoltage(TURBIDITY_PIN);

  // PLACEHOLDER ONLY: replace with your sensor's calibrated conversion formula.
  // This formula is not valid for every pH module.
  float estimatedPH = 7.0 + ((2.5 - phVoltage) * 3.0);

  // Many turbidity modules have different output behavior. This is only a demo.
  bool phInDemoRange = estimatedPH >= DEMO_PH_MIN && estimatedPH <= DEMO_PH_MAX;
  bool turbidityWithinDemoLimit = turbidityVoltage >= DEMO_TURBIDITY_VOLTAGE_LIMIT;

  const char* status = (phInDemoRange && turbidityWithinDemoLimit)
                         ? "CHECK_REQUIRED"
                         : "WARNING_CHECK_REQUIRED";

  Serial.print(phVoltage, 3);
  Serial.print(",");
  Serial.print(turbidityVoltage, 3);
  Serial.print(",");
  Serial.println(status);

  delay(2000);
}
