# WaterGuard AI – Rural Water Safety Monitoring

WaterGuard AI is a **student prototype** for monitoring water-quality indicators and presenting alerts through a simple web dashboard. The prototype combines Arduino sensor readings, a dashboard, sample data, and a baseline machine-learning script.

> **Safety notice:** This is an educational prototype, not a certified water-testing system. Sensor readings and the demo model must not be used to decide whether drinking water is safe. Confirm results with a calibrated instrument and an accredited laboratory or relevant public-health authority.

## Features

- Arduino sketch reads an analog turbidity sensor and a pH sensor.
- Serial output reports sensor readings and a basic threshold-based status.
- Browser dashboard displays a sample tank reading, history, and status.
- CSV sample dataset for testing and demonstrations.
- Optional scikit-learn baseline classifier using the included **synthetic demo data**.
- Architecture notes, setup steps, and basic tests.

## Project structure

```text
WaterGuard-AI/
├── arduino/
│   └── waterguard_sensors.ino
├── web-dashboard/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── ai-model/
│   ├── train_model.py
│   └── requirements.txt
├── data/
│   └── sample_water_quality.csv
├── docs/
│   └── ARCHITECTURE.md
├── tests/
│   └── test_data.py
├── LICENSE
└── README.md
```

## 1. Run the web dashboard

1. Download and extract this project ZIP.
2. Open `web-dashboard/index.html` in a modern browser.
3. The page uses included demonstration values; it does not connect to the Arduino automatically.

To display your own readings, edit the `currentReading` object and `history` array near the top of `web-dashboard/script.js`.

## 2. Upload the Arduino sketch

### Example wiring (verify against your exact sensor modules)

- pH sensor analog output → `A0`
- Turbidity sensor analog output → `A1`
- Sensor VCC/GND → the voltage and ground specified by the sensor manufacturer
- Arduino USB → computer

1. Open `arduino/waterguard_sensors.ino` in Arduino IDE.
2. Select the correct board and port.
3. Upload the sketch and open Serial Monitor at **9600 baud**.
4. Calibrate the pH sensor using its manufacturer instructions and suitable calibration solutions before interpreting measurements.

**Important:** The example conversion values in the sketch are placeholders. Analog turbidity-to-NTU and pH conversion depend on the specific module, calibration, temperature, and circuit. Do not treat the example values as laboratory-grade measurements.

## 3. Run the optional ML demo

Requires Python 3.10+ and internet access only if you need to install packages.

```bash
cd ai-model
python -m pip install -r requirements.txt
python train_model.py
```

The script trains a small baseline classifier on the included **synthetic** dataset and prints a demonstration result. This proves the workflow only; it does not validate water safety or replace domain-reviewed data.

## 4. Sample data

`data/sample_water_quality.csv` contains illustrative readings and demonstration labels. Values and labels are synthetic and are included only for software testing and presentation.

## 5. Suggested next steps

- Calibrate and validate the sensors with a qualified supervisor.
- Replace demo values with real measurements collected responsibly.
- Have domain experts define appropriate limits for the intended use and location.
- Add a backend/API and secure database before connecting live hardware.
- Add QR codes that point to a hosted tank page, without exposing personal or sensitive information.
- Add SMS/WhatsApp notifications only through an authorized provider and with appropriate consent.
- Evaluate the ML model on a representative, independently reviewed dataset before making any claims about prediction accuracy.

## License

Released under the MIT License. See `LICENSE`.
