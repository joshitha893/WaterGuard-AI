"""Educational ML workflow for WaterGuard AI.

The included data is synthetic. This script demonstrates model training and
prediction mechanics only; it is not a validated drinking-water safety model.
"""
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "sample_water_quality.csv"
FEATURES = ["ph_estimate", "turbidity_voltage"]
TARGET = "demo_label"

def main():
    data = pd.read_csv(DATA_FILE)
    X = data[FEATURES]
    y = data[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    print("Demonstration evaluation on synthetic data:")
    print(classification_report(y_test, predictions, zero_division=0))

    demo = pd.DataFrame([{"ph_estimate": 6.2, "turbidity_voltage": 1.3}])
    print("Example input:", demo.to_dict(orient="records")[0])
    print("Predicted demo label:", model.predict(demo)[0])
    print("\nReminder: synthetic demo only; not a water-safety verdict.")

if __name__ == "__main__":
    main()
